"""Privacy-aware operational utilities."""

